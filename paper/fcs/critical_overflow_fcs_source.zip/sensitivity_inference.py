"""Summarize fixed endpoints with model-based simultaneous intervals; no simulation.

The independent-draw allocation model and fixed graphs give a 2/q sensitivity
bound for G/q per changed arrival. Simultaneous intervals for all 24 cell
expectations imply intervals for all 36 within-size, within-tie graph contrasts.
This implication allows arbitrary dependence between the cells.
This is an additional analysis of the saved outcomes, not the original protocol.
"""
from pathlib import Path
from collections import defaultdict
from fractions import Fraction
from itertools import combinations
import argparse
import csv
import hashlib
import json
import math
import statistics

B = Path(__file__).resolve().parent
default_results = B.parent/'experiments/mechanism_robustness_v1_20261021/results'
if not default_results.exists():
    default_results = B/'reproducibility/mechanism_robustness_v1/results'
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--results-dir', type=Path, default=default_results)
parser.add_argument('--output-dir', type=Path, default=B/'verification/sensitivity_intervals_v1')
args = parser.parse_args()
R, O = args.results_dir.resolve(), args.output_dir.resolve()
assert R != O and R not in O.parents, 'Outputs must be separate from fixed results.'

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

names = ['complete', 'permutation16', 'cycle2', 'matching']
inputs = sorted(R.glob('q*_g*_t*_b*.csv')) + [R/'ANALYSIS.json']
before = {p.name: sha(p) for p in inputs}
cells = defaultdict(dict)
strata = defaultdict(dict)
for p in inputs[:-1]:
    with p.open(newline='', encoding='utf-8') as f:
        for row in csv.DictReader(f):
            row = {k: int(v) for k, v in row.items()}
            q, g, tie, rep = row['q'], row['graph'], row['tie'], row['replicate']
            key = (q, g, tie)
            assert rep not in cells[key]
            assert row['overflow'] == row['H0'] + row['H1']
            assert row['gap'] == row['overflow'] - abs(row['delta'])//2
            assert row['gap'] == min(row['H0'],row['U0']) + min(row['H1'],row['U1'])
            cells[key][rep] = row['gap']
            strata[key][rep] = row['graph_label']
assert set(cells) == {(q,g,t) for q in (128,256,512) for g in range(4) for t in range(2)}
assert all(set(v) == set(range(1024)) for v in cells.values())
saved = json.loads((R/'ANALYSIS.json').read_text(encoding='utf-8'))
saved = {(r['q'], names.index(r['graph']), int(r['tie']=='fair')): r for r in saved['summary']}
N, family, allocation_count, alpha = 1024, 60, 24, 0.05
radius = math.sqrt(2/N * math.log(2*allocation_count/alpha))

def interval(center, rad):
    # Print endpoints outwards to four decimal places.
    return [math.floor((float(center)-rad)*10000)/10000,
            math.ceil((float(center)+rad)*10000)/10000]

means = []
for key, rows in sorted(cells.items()):
    q, g, t = key
    mean = Fraction(sum(rows.values()), q*N)
    if g == 1:
        groups = [[rows[i]/q for i in range(N) if strata[key][i] == b] for b in range(4)]
        assert all(len(v) == 256 for v in groups)
        se = math.sqrt(sum(statistics.variance(v)/256 for v in groups))/4
    else:
        se = statistics.stdev([rows[i]/q for i in range(N)])/math.sqrt(N)
    assert float(mean) == saved[key]['gap_mean']
    assert math.isclose(se, saved[key]['gap_mcse'], rel_tol=1e-13)
    means.append(dict(q=q, graph=names[g], tie='fair' if t else 'left', n=N,
                      mean=float(mean), exact_mean=str(mean), mcse=se,
                      simultaneous_interval=interval(mean,radius)))

contrasts = []
for q in (128,256,512):
    for t in range(2):
        for low, high in combinations(range(4),2):
            differences = [cells[q,high,t][i]-cells[q,low,t][i] for i in range(N)]
            mean = Fraction(sum(differences),q*N)
            contrasts.append(dict(q=q, graph=names[high], reference=names[low],
                                  tie='fair' if t else 'left', n=N,
                                  difference=float(mean), exact_difference=str(mean),
                                  simultaneous_interval=interval(mean,2*radius)))
assert len(means) == 24 and len(contrasts) == 36
assert all(r['simultaneous_interval'][0] > 0 for r in means)
assert before == {p.name: sha(p) for p in inputs}
result = dict(analysis='Additional simultaneous inference from the fixed sensitivity endpoints',
              version='sensitivity_intervals_v1', date_beijing='2026-10-21',
              new_simulations=0, new_seeds=0, fixed_inputs_unchanged=True,
              assumptions='Within each cell, independent per-arrival draws and independent trajectory labels in the allocation model; condition on the fixed graphs. Dependence between cells is unrestricted.',
              estimands='Finite-q means conditional on the fixed graphs; the permutation mean equally weights its four fixed graph pairs.',
              interval_method='Bounded-difference tails with Bonferroni allocation over 24 cell means. All 36 graph contrasts inherit difference intervals on the same joint coverage event; no normal approximation.',
              family_size=family, family_failure_probability_upper_bound=alpha,
              bonferroni_allocation_count=allocation_count,
              mean_radius=radius, contrast_radius=2*radius,
              each_cell_two_sided_failure_upper_bound=alpha/allocation_count,
              input_sha256=before, cell_means=means, graph_contrasts=contrasts,
              method_source='https://web.math.princeton.edu/~rvan/APC550.pdf, Theorem 3.11')
O.mkdir(parents=True,exist_ok=True)
(O/'INTERVALS.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
with (O/'INTERVALS.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.writer(f)
    w.writerow(['kind','q','graph','reference','tie','n','estimate','lower','upper'])
    for r in means:
        w.writerow(['mean',r['q'],r['graph'],'',r['tie'],r['n'],r['mean'],*r['simultaneous_interval']])
    for r in contrasts:
        w.writerow(['contrast',r['q'],r['graph'],r['reference'],r['tie'],r['n'],r['difference'],*r['simultaneous_interval']])
key = [r for r in contrasts if r['q']==512 and r['reference']=='complete' and r['graph'] in ('cycle2','matching')]
print(json.dumps(dict(endpoints=24576, family=family, mean_radius=radius,
                     contrast_radius=2*radius, key_contrasts=key,
                     fixed_inputs_unchanged=True),indent=2))
