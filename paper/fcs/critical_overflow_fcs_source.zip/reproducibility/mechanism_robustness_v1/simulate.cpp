#include <algorithm>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <numeric>
#include <random>
#include <stdexcept>
#include <string>
#include <vector>

// Version 1: append-only experiment source. Execute on native cloud Linux.
int main(int argc, char** argv) {
    if (argc != 8) return 2;
    const int q = std::stoi(argv[1]), graph = std::stoi(argv[2]);
    const int fair = std::stoi(argv[3]), graph_label = std::stoi(argv[4]);
    const auto graph_seed = std::stoull(argv[5]);
    std::ifstream seeds(argv[6]);
    std::ofstream out(argv[7]);
    if (!seeds || !out || q < 32 || (q & (q - 1)) || graph < 0 || graph > 3
        || fair < 0 || fair > 1) return 3;
    const int m = q / 2, c = m, mask = m - 1;
    int logq = 0;
    while ((1 << logq) < q) ++logq;
    std::mt19937_64 graph_rng(graph_seed);
    std::vector<std::vector<int>> perms(32, std::vector<int>(m));
    for (auto& p : perms) {
        std::iota(p.begin(), p.end(), 0);
        // Rejection sampling makes Fisher--Yates independent of STL shuffle.
        for (int k = m - 1; k > 0; --k) {
            const uint64_t bound = uint64_t(k + 1), threshold = -bound % bound;
            uint64_t u;
            do { u = graph_rng(); } while (u < threshold);
            std::swap(p[k], p[u % bound]);
        }
    }
    out << "q,graph,tie,graph_label,replicate,delta,overflow,H0,U0,H1,U1,gap,mirror_checked\n";
    int label;
    uint64_t arrival_seed, tie_seed;
    while (seeds >> label >> arrival_seed >> tie_seed) {
        std::mt19937_64 arrivals(arrival_seed), ties(tie_seed);
        std::vector<int> a(2 * q, 0), mirror(2 * q, 0);
        // Left/right conjugacy is checked on the first 8 labels of each block.
        const bool check_mirror = !fair && (label % 256 < 8);
        const int64_t nstar = int64_t(q) * q;
        for (int64_t n = 0; n < nstar; ++n) {
            const uint64_t u = arrivals();
            const bool cross = (u & (q - 1)) == 0; // epsilon = 1/q exactly.
            const int s = int((u >> logq) & 1);
            const int i = int(arrivals() & mask), t = int(arrivals() & mask);
            int j = t;
            if (!cross) {
                if (graph == 1) j = perms[16 * s + (t & 15)][i];
                if (graph == 2) j = (i + (t & 1)) & mask;
                if (graph == 3) j = i;
            }
            const int left = s * q + i;
            const int right = (cross ? 1 - s : s) * q + m + j;
            const bool choose_left = a[left] < a[right]
                || (a[left] == a[right] && (!fair || (ties() & 1) == 0));
            const int chosen = choose_left ? left : right;
            if (check_mirror) {
                const int ml = right ^ m, mr = left ^ m;
                const int mc = mirror[ml] < mirror[mr] ? ml : mr;
                if (mc != (chosen ^ m)) throw std::runtime_error("tie conjugacy");
                ++mirror[mc];
            }
            ++a[chosen];
        }
        int64_t H[2] = {}, U[2] = {}, total[2] = {};
        for (int v = 0; v < 2 * q; ++v) {
            const int s = v / q;
            total[s] += a[v];
            H[s] += std::max(a[v] - c, 0);
            U[s] += std::max(c - a[v], 0);
            if (check_mirror && a[v] != mirror[v ^ m])
                throw std::runtime_error("mirror endpoint");
        }
        const auto delta = total[0] - total[1];
        const auto spill = H[0] + H[1];
        const auto gap = spill - std::abs(delta) / 2;
        if (total[0] + total[1] != nstar || delta % 2 || gap < 0
            || gap != std::min(H[0], U[0]) + std::min(H[1], U[1]))
            throw std::runtime_error("mass or aggregation identity");
        out << q << ',' << graph << ',' << fair << ',' << graph_label << ','
            << label << ',' << delta << ',' << spill << ',' << H[0] << ','
            << U[0] << ',' << H[1] << ',' << U[1] << ',' << gap << ','
            << int(check_mirror) << '\n';
    }
    if (!out) return 4;
}
