"""Independent integer and hash audit of saved outcomes. No random execution."""
from pathlib import Path
from collections import defaultdict
import csv
import hashlib
import json
import math
import statistics

B=Path(__file__).resolve().parent
R=B/"results"
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
expected=json.loads((R/"FILES.json").read_text())
assert all(sha(R/name)==digest for name,digest in expected.items())
env=json.loads((R/"environment.json").read_text())
assert env["commit"]=="3daccb3bdb4503a79accc26ba2f214bf9d79be30"
uploaded={name:(B/name).read_bytes().replace(b"\r\n",b"\n") for name in env["source_sha256"]}
assert all(hashlib.sha256(uploaded[n]).hexdigest()==h for n,h in env["source_sha256"].items())
local_lookup=(B/"FROZEN_OVERFLOW_NODES.csv").read_bytes()
assert local_lookup.replace(b"\r\n",b"\n")==uploaded["FROZEN_OVERFLOW_NODES.csv"]
assert sha(B/"FROZEN_OVERFLOW_NODES.csv")=="7e36daf91842cbd07da17e84c67cf0dac113a3c8c6919144652baac95e9725a7"
original_lookup=B.parents[1]/"current/evidence/FROZEN_OVERFLOW_NODES.csv"
if original_lookup.exists():
    assert sha(B/"FROZEN_OVERFLOW_NODES.csv")==sha(original_lookup)
groups=defaultdict(list)
mirror=0
for p in R.glob("q*_g*_t*_b*.csv"):
    for row in csv.DictReader(p.open()):
        d={k:int(v) for k,v in row.items()}
        q=d["q"]
        w0=d["H0"]-d["U0"];w1=d["H1"]-d["U1"]
        assert w0+w1==0 and w0-w1==d["delta"]
        spill=d["H0"]+d["H1"]
        absolute=d["H0"]+d["U0"]+d["H1"]+d["U1"]
        assert 2*spill==absolute
        assert 2*d["gap"]==absolute-abs(w0)-abs(w1)
        assert d["gap"]>=0
        assert d["overflow"]==spill
        assert d["mirror_checked"]==int(d["tie"]==0 and d["replicate"]%256<8)
        mirror+=d["mirror_checked"]
        groups[q,d["graph"],d["tie"]].append(d)
summary=list(csv.DictReader((R/"summary.csv").open()))
names=("complete","permutation16","cycle2","matching")
assert len(groups)==len(summary)==24
for d in summary:
    q=int(d["q"]);g=names.index(d["graph"]);t=int(d["tie"]=="fair")
    rows=groups[q,g,t]
    assert len(rows)==1024 and len({z["replicate"] for z in rows})==1024
    assert {z["replicate"] for z in rows}==set(range(1024))
    for field,col in (("gap_mean","gap"),("overflow_mean","overflow")):
        assert abs(float(d[field])-sum(z[col] for z in rows)/(q*1024))<1e-14
    assert abs(float(d["community_mean"])-sum(abs(z["delta"]) for z in rows)/(2*q*1024))<1e-14
    se=statistics.stdev(z["gap"]/q for z in rows)/32
    if g==1:
        strata=[[z["gap"]/q for z in rows if z["graph_label"]==k] for k in range(4)]
        assert all(len(z)==256 for z in strata)
        se=math.sqrt(sum(statistics.variance(z)/len(z) for z in strata))/4
    assert abs(float(d["gap_mcse"])-se)<1e-14
assert mirror==384
out=dict(status="passed",endpoints=sum(map(len,groups.values())),cells=len(groups),
    mirror_trajectories=mirror,returned_hashes_verified=len(expected),
    source_commit=env["commit"],native_linux=env["platform"].startswith("Linux"),
    exact_integer_identities=True,independent_saved_data_mean_and_mcse_recomputation=True,
    original_lookup_bytes_unchanged=True,
    upload_lookup_normalization="CRLF to LF only; every CSV value is unchanged; cloud hash verified against the exact uploaded content.",
    limitations="This checks saved data and source correspondence. It is not an independent rerun or a proof of universality.")
(B/"RETURN_VERIFICATION.json").write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
