"""Run the fixed experiment on native Linux; never execute on local Windows."""
from pathlib import Path
import concurrent.futures as cf
import csv
import hashlib
import json
import os
import platform
import secrets
import subprocess
import time

B = Path(__file__).resolve().parent
R = B / "results"

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    if platform.system() != "Linux":
        raise SystemExit("Native cloud Linux required by the fixed protocol.")
    R.mkdir(exist_ok=True)
    manifest = R / "seeds.json"
    if not manifest.exists():
        data = {
            "arrival": {str(q): [[secrets.randbits(64), secrets.randbits(64)]
                                for _ in range(1024)] for q in (128, 256, 512)},
            "graphs": {str(q): [secrets.randbits(64) for _ in range(4)]
                       for q in (128, 256, 512)},
        }
        manifest.write_text(json.dumps(data, indent=2) + "\n")
    data = json.loads(manifest.read_text())
    source_files = ("simulate.cpp", "run_cloud.py", "analyze.py", "PROTOCOL.txt",
                    "FROZEN_OVERFLOW_NODES.csv")
    environment = {
        "platform": platform.platform(), "cpu_count": os.cpu_count(),
        "commit": os.environ.get("GITHUB_SHA"),
        "run_id": os.environ.get("GITHUB_RUN_ID"),
        "compiler": subprocess.check_output(["g++", "--version"], text=True),
        "source_sha256": {name: sha(B / name) for name in source_files},
        "seeds_sha256": sha(manifest),
        "start_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }
    (R / "environment.json").write_text(json.dumps(environment, indent=2))
    with (R / "compiler.log").open("w") as log:
        subprocess.run(["g++", "-std=c++17", "-O3", "-Wall", "-Wextra",
                        "-pedantic", str(B / "simulate.cpp"), "-o", str(R / "simulate")],
                       stdout=log, stderr=log, check=True)
    jobs = []
    for q in (128, 256, 512):
        for graph in range(4):
            for fair in range(2):
                for gl in range(4 if graph == 1 else 1):
                    stem = f"q{q}_g{graph}_t{fair}_b{gl}"
                    seedfile = R / f"{stem}.seeds.txt"
                    indices = range(gl * 256, (gl + 1) * 256) if graph == 1 else range(1024)
                    seedfile.write_text("".join(
                        f"{i} {data['arrival'][str(q)][i][0]} {data['arrival'][str(q)][i][1]}\n"
                        for i in indices))
                    jobs.append((stem, [str(R / "simulate"), str(q), str(graph),
                        str(fair), str(gl), str(data["graphs"][str(q)][gl]),
                        str(seedfile), str(R / f"{stem}.csv")]))
    def run(job):
        stem, command = job
        start = time.monotonic()
        with (R / f"{stem}.log").open("w") as log:
            subprocess.run(command, check=True, stdout=log, stderr=log)
        print(f"{stem} finished in {time.monotonic()-start:.1f}s", flush=True)
    with cf.ThreadPoolExecutor(max_workers=min(4, os.cpu_count() or 1)) as pool:
        list(pool.map(run, jobs))
    subprocess.run(["python", str(B / "analyze.py")], check=True)
    # Binary is reproducible from the fixed source; retain its hash, not its bytes.
    environment["binary_sha256"] = sha(R / "simulate")
    environment["end_utc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    (R / "environment.json").write_text(json.dumps(environment, indent=2))
    (R / "FILES.json").write_text(json.dumps({p.name: sha(p) for p in R.iterdir()
        if p.is_file() and p.name not in ("FILES.json", "simulate")}, indent=2))

if __name__ == "__main__":
    main()
