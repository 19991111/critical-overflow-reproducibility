"""Analyze saved cloud endpoints; no simulation or fitted model."""
from pathlib import Path
from collections import defaultdict
import csv
import json
import math
import statistics as st

B = Path(__file__).resolve().parent
R = B / "results"
NAMES = ("complete", "permutation16", "cycle2", "matching")

def stats(x):
    return st.mean(x), st.stdev(x) / math.sqrt(len(x)) if len(x) > 1 else None

def main():
    import numpy as np
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    lookup = list(csv.DictReader((B / "FROZEN_OVERFLOW_NODES.csv").open()))
    xs = np.array([float(x["d"]) for x in lookup])
    ys = np.array([float.fromhex(x["S0_hex"]) for x in lookup])
    cells = defaultdict(list)
    for p in sorted(R.glob("q*_g*_t*_b*.csv")):
        for d in csv.DictReader(p.open()):
            d = {k: int(v) for k, v in d.items()}
            q = d["q"]
            assert d["overflow"] == d["H0"] + d["H1"]
            assert d["H0"] - d["U0"] == d["delta"] // 2
            assert d["H1"] - d["U1"] == -d["delta"] // 2
            assert d["gap"] == min(d["H0"], d["U0"]) + min(d["H1"], d["U1"])
            assert d["gap"] == d["overflow"] - abs(d["delta"]) // 2 >= 0
            cells[q, d["graph"], d["tie"]].append(d)
    assert set(cells) == {(q, g, t) for q in (128,256,512) for g in range(4) for t in range(2)}
    summary, graph_summary, paired = [], [], []
    mirrors = 0
    for (q, g, t), rows in sorted(cells.items()):
        assert len(rows) == 1024 and {d["replicate"] for d in rows} == set(range(1024))
        assert {d["graph_label"] for d in rows} == (set(range(4)) if g == 1 else {0})
        mirrors += sum(d["mirror_checked"] for d in rows)
        x = [d["overflow"] / q for d in rows]
        gaps = [d["gap"] / q for d in rows]
        base = [abs(d["delta"]) / (2*q) for d in rows]
        arg = np.abs([d["delta"] / q for d in rows])
        assert max(arg) <= xs[-1]
        prediction = np.interp(arg, xs, ys)
        near = [d["overflow"]/q for d in rows if abs(d["delta"])/q <= 1/8]
        mean, se = stats(gaps)
        if g == 1:
            groups = [[d["gap"]/q for d in rows if d["graph_label"] == k] for k in range(4)]
            se = math.sqrt(sum(st.variance(z)/len(z) for z in groups))/4
            for k, z in enumerate(groups):
                gm, gs = stats(z)
                graph_summary.append(dict(q=q, tie=t, graph_label=k, n=len(z), gap_mean=gm, gap_mcse=gs))
        summary.append(dict(q=q,graph=NAMES[g],tie="fair" if t else "left",n=len(rows),
            overflow_mean=st.mean(x),community_mean=st.mean(base),gap_mean=mean,gap_mcse=se,
            gap_positive=sum(v>0 for v in gaps),near_n=len(near),
            near_overflow_mean=st.mean(near) if near else None,
            original_profile_mae=float(np.mean(np.abs(np.array(x)-prediction))),
            community_mae=st.mean(gaps)))
    for q in (128,256,512):
        for g in range(4):
            a={d["replicate"]:d for d in cells[q,g,0]}
            b={d["replicate"]:d for d in cells[q,g,1]}
            diffs=[(b[k]["gap"]-a[k]["gap"])/q for k in range(1024)]
            dm, ds=stats(diffs)
            if g==1:
                ds=math.sqrt(sum(st.variance(diffs[k*256:(k+1)*256])/256 for k in range(4)))/4
            paired.append(dict(q=q,graph=NAMES[g],fair_minus_left_gap=dm,mcse=ds,n=1024))
    for name, rows in (("summary.csv",summary),("graph_summary.csv",graph_summary),("paired.csv",paired)):
        with (R/name).open("w",newline="") as f:
            w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    assert mirrors == 384, mirrors
    report=dict(endpoints=sum(map(len,cells.values())),cells=len(cells),
        mirror_trajectories=mirrors,endpoint_identities_pass=True,
        interpretation="Finite-size sensitivity only; MCSE is conditional on fixed graphs, not a certified confidence bound.",
        summary=summary,paired=paired)
    (R/"ANALYSIS.json").write_text(json.dumps(report,indent=2))
    plt.rcParams.update({"font.size":10,"axes.spines.top":False,"axes.spines.right":False})
    fig,axes=plt.subplots(1,2,figsize=(10.5,3.6),layout="constrained")
    colors={"complete":"#175f9c","permutation16":"#b75717","cycle2":"#397844","matching":"#9a3e62"}
    for ax,graphs in zip(axes,[("complete","permutation16"),("cycle2","matching")]):
        for graph in graphs:
            for tie in ("left","fair"):
                z=sorted((d for d in summary if d["graph"]==graph and d["tie"]==tie),key=lambda d:d["q"])
                ax.errorbar([d["q"] for d in z],[d["gap_mean"] for d in z],
                    yerr=[2*d["gap_mcse"] for d in z],color=colors[graph],
                    linestyle="-" if tie=="left" else "--",marker="o" if tie=="left" else "s",
                    label=f"{graph}, {tie}",capsize=3)
        ax.set_xscale("log",base=2);ax.set_xticks([128,256,512],["128","256","512"])
        ax.set_xlabel("Buckets per community q");ax.set_ylabel("Mean omitted overflow G / q")
        ax.grid(alpha=.2);ax.legend(fontsize=8)
    axes[0].set_title("Complete and fixed sparse internal graphs")
    axes[1].set_title("Cycle and disconnected control")
    fig.savefig(R/"robustness.pdf");fig.savefig(R/"robustness.png",dpi=200)
    print(json.dumps({k:v for k,v in report.items() if k not in ("summary","paired")},indent=2))

if __name__ == "__main__":
    main()
