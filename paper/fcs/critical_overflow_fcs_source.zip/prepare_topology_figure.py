"""Plot fixed sensitivity summaries; no simulation, seeds, or integration."""
from pathlib import Path
import csv, hashlib, json
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

B=Path(__file__).resolve().parent
source=B.parent/"experiments/mechanism_robustness_v1_20261021/results/summary.csv"
if not source.exists():
    source=B/"reproducibility/mechanism_robustness_v1/results/summary.csv"
rows=list(csv.DictReader(source.open(encoding="utf-8")))
graphs=("complete","permutation16","cycle2","matching")
selected={(r["graph"],r["tie"]):r for r in rows if int(r["q"])==512}
assert len(selected)==8
assert all(int(r["n"])==1024 for r in selected.values())
plt.rcParams.update({"font.family":"DejaVu Sans","font.size":9,
    "axes.labelsize":10,"legend.fontsize":9,"pdf.fonttype":42,
    "svg.fonttype":"none","axes.spines.top":False,"axes.spines.right":False})
fig,(ax,amp)=plt.subplots(1,2,figsize=(7.8,3.25),sharey=True,
    gridspec_kw={"width_ratios":[1.35,1]})
fig.subplots_adjust(left=.205,right=.985,bottom=.23,top=.84,wspace=.30)
y=np.arange(4); height=.22
data={tie:{g:{"mean_gap_over_q":float(selected[g,tie]["gap_mean"]),
    "mcse":float(selected[g,tie]["gap_mcse"])} for g in graphs}
    for tie in ("left","fair")}
colors={"left":"#246384","fair":"#C99B58"}
for tie,shift,label in (("left",-height*.65,"Left ties"),
                        ("fair",height*.65,"Fair ties")):
    values=[data[tie][g]["mean_gap_over_q"] for g in graphs]
    errors=[2*data[tie][g]["mcse"] for g in graphs]
    ax.barh(y+shift,values,height,color=colors[tie],label=label,xerr=errors,
        capsize=1.5,error_kw={"elinewidth":.6,"capthick":.6,"ecolor":"#425466"},zorder=3)
    for py,value,error in zip(y+shift,values,errors):
        ax.text(value+error+.17,py,f"{value:.4f}",va="center",ha="left",
            fontsize=7.7,color="#344653")
ax.set_yticks(y,["Complete bipartite","16 permutations","Degree-two cycle","Disconnected\nmatching"])
ax.set_ylim(3.52,-.52)
ax.set_xlim(0,11)
ax.set_xticks([0,2,4,6,8,10])
ax.set_xlabel(r"Mean omitted overflow $G_c/q$",labelpad=8,fontsize=9)
ax.set_title("(a) Overflow omitted by totals",loc="left",pad=16,fontsize=10)
ax.tick_params(axis="y",length=0,pad=10,labelsize=9)
ax.tick_params(axis="x",length=3,labelsize=8,colors="#61717e")
ax.grid(axis="x",color="#e7edf1",linewidth=.65,zorder=0)
baseline=data["left"]["complete"]["mean_gap_over_q"]
ratio={g:data["left"][g]["mean_gap_over_q"]/baseline for g in graphs}
amp.axvline(1,color="#aab9c3",linestyle=(0,(3,3)),linewidth=.8,zorder=1)
for i,g in enumerate(graphs):
    accent="#246384" if i<2 else "#173f58"
    amp.hlines(i,1,ratio[g],color="#c0d0da",linewidth=2,zorder=2)
    amp.scatter(ratio[g],i,s=27 if i<2 else 42,color=accent,zorder=3)
    amp.text(35.5,i,f"{ratio[g]:.2f}×",ha="right",va="center",
        fontsize=10 if i<2 else 11,fontweight="normal" if i<2 else "bold",color=accent)
amp.set_xlim(0,36)
amp.set_xticks([1,5,10,15,20],["1","5","10","15","20"])
amp.set_xlabel("Ratio to complete bipartite",labelpad=8,fontsize=9)
amp.set_title("(b) Left-tie amplification",loc="left",pad=16,fontsize=10)
amp.tick_params(axis="y",left=False,labelleft=False)
amp.tick_params(axis="x",length=3,labelsize=8,colors="#61717e")
amp.grid(axis="x",color="#edf1f4",linewidth=.65,zorder=0)
for panel in (ax,amp):
    panel.spines["left"].set_visible(False)
    panel.spines["bottom"].set_color("#b8c4cd")
    panel.spines["bottom"].set_linewidth(.7)
handles,labels=ax.get_legend_handles_labels()
fig.legend(handles,labels,loc="lower center",bbox_to_anchor=(.60,.015),
    ncol=2,frameon=False,fontsize=8.5,handlelength=1.4,columnspacing=2.2)
for suffix in ("pdf","png","svg"):
    fig.savefig(B/f"manuscript/figures/topology_amplification.{suffix}",dpi=220)
receipt=dict(source=str(source),source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
    q=512,kappa=1,lambda_=1,n_per_cell=1024,values=data,left_tie_relative_to_complete=ratio,
    error_bars="twice conditional MCSE, not confidence bounds",new_simulations=0,
    visual_emphasis="Aligned horizontal bars for both tie rules and a separate left-tie amplification panel with direct ratio labels.",
    outputs={s:hashlib.sha256((B/f"manuscript/figures/topology_amplification.{s}").read_bytes()).hexdigest() for s in ("pdf","png","svg")})
(B/"verification/TOPOLOGY_FIGURE_CHECKS.json").write_text(json.dumps(receipt,indent=2),encoding="utf-8")
print(json.dumps({"q":512,"left_tie_relative_to_complete":ratio,"new_simulations":0},indent=2))
